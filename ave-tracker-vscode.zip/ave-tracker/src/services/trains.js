import { demoTrains } from '../data/demoTrains';
const API_URL = import.meta.env.VITE_TRAINS_API_URL;
export const isDemoMode = !API_URL;
function normalizeTrain(x) {
 const lat=Number(x.lat), lng=Number(x.lng), delay=Number(x.delayMinutes), speed=Number(x.speedKmh), progress=Number(x.progress);
 return {id:String(x.id??x.number??'unknown'),number:String(x.number??x.id??'Tren sin número'),operator:x.operator??'Operador no indicado',origin:x.origin??'Origen no disponible',destination:x.destination??'Destino no disponible',lat:Number.isFinite(lat)?lat:null,lng:Number.isFinite(lng)?lng:null,delayMinutes:x.delayMinutes==null?null:(Number.isFinite(delay)?delay:null),status:['on_time','delayed','stopped'].includes(x.status)?x.status:'unknown',speedKmh:x.speedKmh==null?null:(Number.isFinite(speed)?speed:null),nextStop:x.nextStop??'No disponible',progress:Number.isFinite(progress)?Math.max(0,Math.min(100,progress)):null,departure:x.departure??'--:--',arrival:x.arrival??'--:--',source:x.source??'Fuente no indicada'};
}
export async function fetchTrains(signal) {
 if(!API_URL) return demoTrains.map(normalizeTrain);
 const r=await fetch(API_URL,{signal,headers:{Accept:'application/json'}});
 if(!r.ok) throw new Error(`La fuente respondió con HTTP ${r.status}`);
 const data=await r.json(); if(!Array.isArray(data)) throw new Error('La API debe devolver un array JSON.');
 return data.map(normalizeTrain);
}
