# AVE Tracker España

Panel web de seguimiento ferroviario construido con React, Vite y Leaflet.

## Requisitos
- Node.js 20 o superior
- npm

## Ejecutar en local
```bash
npm install
npm run dev
```
Abre la URL que indique Vite (normalmente http://localhost:5173).

## Compilar
```bash
npm run build
npm run preview
```

## Datos y modo demostración
La aplicación arranca con circulaciones y posiciones **ficticias**, claramente marcadas como DEMO. No son trenes reales ni deben usarse para tomar decisiones de viaje.

Para conectar datos reales, configura `VITE_TRAINS_API_URL` con un endpoint de tu backend que consuma una fuente autorizada (por ejemplo, datos abiertos oficiales de Renfe, sujeto a disponibilidad y condiciones de uso). El endpoint debe devolver un array JSON con objetos que contengan:

```json
[{"id":"AVE-001","number":"AVE 001","operator":"Renfe","origin":"Madrid","destination":"Barcelona","lat":40.4,"lng":-3.7,"delayMinutes":5,"status":"delayed","speedKmh":230,"nextStop":"Zaragoza","progress":40,"departure":"10:00","arrival":"12:45","source":"Fuente de datos","lastUpdate":"2026-10-30T10:30:00Z"}]
```

Estados admitidos: `on_time`, `delayed`, `stopped`, `unknown`. No se inventan posiciones cuando faltan coordenadas. No pongas claves privadas en variables `VITE_*`: son visibles en el navegador. Usa un backend para credenciales, límites de peticiones y normalización.

## Publicación
Despliega la carpeta `dist` en un hosting estático. Para GitHub Pages, ajusta `base` en `vite.config.js` al nombre del repositorio y configura un workflow de despliegue.

Proyecto independiente, no oficial ni afiliado a Renfe.
